# Machine Learning Course - Missing Link Project

Link prediction on the French web.

This a project of a group of three students for a Kaggle competition on the Machine Learning I course in École Polytechnique

Students:

- [João Henrique Oliveira](https://github.com/JoaoHenriqueOliveira)
- [Matheus Douglas de Matos Marcondes](https://github.com/mathdoug)
- [Vathana Thy](https://github.com/vathanathy)
